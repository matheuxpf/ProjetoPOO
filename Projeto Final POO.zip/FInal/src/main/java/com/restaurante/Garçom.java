package com.restaurante;

import java.io.Serializable;
import java.util.ArrayList;

public class Garçom extends Pessoa implements Serializable {
    private double salario;
    private ArrayList<Mesa> mesas;
    private ArrayList<Pedido> pedidos;

    public Garçom(String nome, String cpf, double salario) {
        this.nome = nome;
        this.cpf = cpf;
        this.salario = salario;
        this.mesas = new ArrayList<>();
        this.pedidos = new ArrayList<>();
    }

    public double getSalario() {
        return salario;
    }

    public void atribuirMesa(Mesa mesa) {
        this.mesas.add(mesa);
    }

    public void realizarPedido(Mesa mesa, ItemDoMenu... itens) {
        Pedido pedido = new Pedido(mesa, itens);
        this.pedidos.add(pedido);
        mesa.adicionarPedido(pedido);
    }

    public void printPedidos() {
        for (Pedido pedido : pedidos) {
            System.out.println(pedido);
        }
    }
}
