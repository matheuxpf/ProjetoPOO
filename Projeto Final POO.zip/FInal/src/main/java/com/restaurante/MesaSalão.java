package com.restaurante;

/**
 * A classe MesaSalão representa uma mesa localizada no salão,
 * herdando as propriedades e comportamentos da classe Mesa.
 */
public class MesaSalão extends Mesa {

    /**
     * Construtor da classe MesaSalão. Inicializa a mesa do salão
     * usando o construtor da classe base Mesa.
     */
    public MesaSalão() {
        super();
    }
}
