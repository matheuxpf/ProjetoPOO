package com.restaurante;

/**
 * A interface PessoaInterface define os métodos para obter e definir informações básicas
 * de uma pessoa, como nome, telefone e CPF.
 */
public interface PessoaInterface {

    /**
     * Obtém o nome da pessoa.
     *
     * @return O nome da pessoa.
     */
    String getNome();

    /**
     * Obtém o telefone da pessoa.
     *
     * @return O telefone da pessoa.
     */
    String getTelefone();

    /**
     * Obtém o CPF da pessoa.
     *
     * @return O CPF da pessoa.
     */
    String getCpf();

    /**
     * Define o nome da pessoa.
     *
     * @param nome O nome da pessoa.
     */
    void setNome(String nome);

    /**
     * Define o telefone da pessoa.
     *
     * @param telefone O telefone da pessoa.
     */
    void setTelefone(String telefone);

    /**
     * Define o CPF da pessoa.
     *
     * @param cpf O CPF da pessoa.
     */
    void setCpf(String cpf);
}
