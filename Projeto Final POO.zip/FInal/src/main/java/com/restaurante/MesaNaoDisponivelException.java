package com.restaurante;

public class MesaNaoDisponivelException extends Exception {
    public MesaNaoDisponivelException(String mensagem) {
        super(mensagem);
    }
}
