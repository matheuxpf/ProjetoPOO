package com.restaurante;

/**
 * A classe MesaVaranda representa uma mesa localizada na varanda,
 * herdando as propriedades e comportamentos da classe Mesa.
 */
public class MesaVaranda extends Mesa {

    /**
     * Construtor da classe MesaVaranda. Inicializa a mesa da varanda
     * usando o construtor da classe base Mesa.
     */
    public MesaVaranda() {
        super();
    }
}
