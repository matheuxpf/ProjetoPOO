package com.restaurante;

import java.util.ArrayList;
import java.io.Serializable;

/**
 * A classe Pedido representa um pedido feito em uma mesa, contendo uma lista de itens do menu e
 * informações sobre o número do pedido e a mesa associada.
 */
public class Pedido implements Serializable {

    /**
     * Número estático usado para gerar números únicos para cada pedido.
     */
    private static int num = 0;

    /**
     * Número do pedido.
     */
    private int numPedido;

    /**
     * Mesa associada ao pedido.
     */
    private Mesa mesa;

    /**
     * Lista de itens do menu associados ao pedido.
     */
    private ArrayList<ItemDoMenu> itensDoPedido;

    /**
     * Construtor da classe Pedido. Inicializa o pedido com uma mesa e uma lista de itens do menu.
     *
     * @param mesa  A mesa associada ao pedido.
     * @param itens Os itens do menu incluídos no pedido.
     */
    public Pedido(Mesa mesa, ItemDoMenu... itens) {
        this.numPedido = ++num;
        this.mesa = mesa;
        this.itensDoPedido = new ArrayList<>();
        for (ItemDoMenu item : itens) {
            item.reduzirEstoque();
            itensDoPedido.add(item);
        }
    }

    /**
     * Calcula o total do pedido somando o preço de todos os itens.
     *
     * @return O total do pedido.
     */
    public double calcularTotal() {
        double total = 0;
        for (ItemDoMenu item : itensDoPedido) {
            total += item.getPreco();
        }
        return total;
    }

    /**
     * Retorna uma representação em String do pedido.
     *
     * @return Uma String que representa o pedido.
     */
    @Override
    public String toString() {
        StringBuilder printPedido = new StringBuilder();
        printPedido.append("Pedido número ").append(this.numPedido).append(" da mesa ").append(mesa.getNumeroDaMesa()).append(":\n");
        for (ItemDoMenu itemDoMenu : itensDoPedido) {
            printPedido.append(itemDoMenu.getNome()).append("\n");
        }
        return printPedido.toString();
    }

    /**
     * Obtém o número estático usado para gerar números únicos para cada pedido.
     *
     * @return O número estático.
     */
    public static int getNum() {
        return num;
    }

    /**
     * Define o número estático usado para gerar números únicos para cada pedido.
     *
     * @param num O novo número estático.
     */
    public static void setNum(int num) {
        Pedido.num = num;
    }

    /**
     * Obtém o número do pedido.
     *
     * @return O número do pedido.
     */
    public int getNumPedido() {
        return numPedido;
    }

    /**
     * Define o número do pedido.
     *
     * @param numPedido O novo número do pedido.
     */
    public void setNumPedido(int numPedido) {
        this.numPedido = numPedido;
    }

    /**
     * Obtém a mesa associada ao pedido.
     *
     * @return A mesa associada ao pedido.
     */
    public Mesa getMesa() {
        return mesa;
    }

    /**
     * Define a mesa associada ao pedido.
     *
     * @param mesa A nova mesa associada ao pedido.
     */
    public void setMesa(Mesa mesa) {
        this.mesa = mesa;
    }

    /**
     * Obtém a lista de itens do menu associados ao pedido.
     *
     * @return A lista de itens do menu associados ao pedido.
     */
    public ArrayList<ItemDoMenu> getItensDoPedido() {
        return itensDoPedido;
    }

    /**
     * Define a lista de itens do menu associados ao pedido.
     *
     * @param itensDoPedido A nova lista de itens do menu associados ao pedido.
     */
    public void setItensDoPedido(ArrayList<ItemDoMenu> itensDoPedido) {
        this.itensDoPedido = itensDoPedido;
    }
}
