package com.restaurante;

import java.io.Serializable;
import java.util.ArrayList;

public class Menu implements Serializable {
    private ArrayList<ItemDoMenu> itens;

    public Menu() {
        this.itens = new ArrayList<>();
    }

    public void adicionaItem(ItemDoMenu item) {
        this.itens.add(item);
    }

    public String[] getItemNames() {
        String[] names = new String[itens.size()];
        for (int i = 0; i < itens.size(); i++) {
            names[i] = itens.get(i).getNome();
        }
        return names;
    }

    public ItemDoMenu getItemByName(String name) {
        for (ItemDoMenu item : itens) {
            if (item.getNome().equalsIgnoreCase(name)) {
                return item;
            }
        }
        return null;
    }

    public void printMenu() {
        System.out.println("Menu:");
        for (ItemDoMenu item : itens) {
            System.out.println(item.getNome() + " - " + item.getPreco());
        }
    }
}
