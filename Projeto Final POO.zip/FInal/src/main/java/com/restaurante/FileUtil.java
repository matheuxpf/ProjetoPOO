package com.restaurante;

import java.io.*;
import java.util.ArrayList;

/**
 * A classe FileUtil fornece métodos utilitários para salvar e ler dados de clientes em um arquivo.
 */
public class FileUtil {

    /**
     * Salva uma lista de clientes em um arquivo.
     *
     * @param clientes A lista de clientes a ser salva.
     * @param fileName O nome do arquivo onde os clientes serão salvos.
     */
    public static void saveClientesToFile(ArrayList<Cliente> clientes, String fileName) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            for (Cliente cliente : clientes) {
                writer.write(cliente.getNome() + "," + cliente.getTelefone() + "," + cliente.getCodigoDeAtendimento() + "," + cliente.getStatus() + "," + cliente.getMesa().getNumeroDaMesa());
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Lê uma lista de clientes de um arquivo.
     *
     * @param fileName O nome do arquivo de onde os clientes serão lidos.
     * @return A lista de clientes lida do arquivo.
     */
    public static ArrayList<Cliente> readClientesFromFile(String fileName) {
        ArrayList<Cliente> clientes = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                if (data.length >= 5) {
                    Mesa mesa = new Mesa();
                    mesa.setNumeroDaMesa(Integer.parseInt(data[4]));
                    Cliente cliente = new Cliente(data[0], data[1], mesa);
                    cliente.setCodigoDeAtendimento(Integer.parseInt(data[2]));
                    cliente.setStatus(data[3].charAt(0));
                    clientes.add(cliente);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return clientes;
    }
}
