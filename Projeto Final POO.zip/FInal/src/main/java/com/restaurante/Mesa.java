package com.restaurante;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * A classe Mesa representa uma mesa em um restaurante, com um número único,
 * status de disponibilidade e uma lista de pedidos associados.
 */
public class Mesa implements Serializable {
    /**
     * Número estático usado para gerar números únicos para cada mesa.
     */
    private static int numero = 0;

    /**
     * Número da mesa.
     */
    private int numeroDaMesa;

    /**
     * Indica se a mesa está disponível.
     */
    private boolean disponivel;

    /**
     * Lista de pedidos associados à mesa.
     */
    private ArrayList<Pedido> pedidos;

    /**
     * Construtor da classe Mesa. Inicializa a mesa com um número único e a
     * define como disponível.
     */
    public Mesa() {
        this.numeroDaMesa = ++numero;
        this.disponivel = true;
        this.pedidos = new ArrayList<>();
    }

    /**
     * Obtém o número da mesa.
     *
     * @return O número da mesa.
     */
    public int getNumeroDaMesa() {
        return numeroDaMesa;
    }

    /**
     * Define o número da mesa.
     *
     * @param numeroDaMesa O novo número da mesa.
     */
    public void setNumeroDaMesa(int numeroDaMesa) {
        this.numeroDaMesa = numeroDaMesa;
    }

    /**
     * Verifica se a mesa está disponível.
     *
     * @return true se a mesa estiver disponível, false caso contrário.
     */
    public boolean isDisponivel() {
        return disponivel;
    }

    /**
     * Define a disponibilidade da mesa.
     *
     * @param disponivel true para definir a mesa como disponível, false caso contrário.
     */
    public void setDisponivel(boolean disponivel) {
        this.disponivel = disponivel;
    }

    /**
     * Obtém a lista de pedidos da mesa.
     *
     * @return A lista de pedidos da mesa.
     */
    public ArrayList<Pedido> getPedidos() {
        return pedidos;
    }

    /**
     * Adiciona um pedido à lista de pedidos da mesa.
     *
     * @param pedido O pedido a ser adicionado.
     */
    public void adicionarPedido(Pedido pedido) {
        this.pedidos.add(pedido);
    }

    /**
     * Calcula o total da conta da mesa somando o valor de todos os pedidos.
     *
     * @return O total da conta da mesa.
     */
    public double calcularConta() {
        double total = 0;
        for (Pedido pedido : pedidos) {
            total += pedido.calcularTotal();
        }
        return total;
    }

    /**
     * Calcula a conta da mesa e emite uma fatura imprimindo o total no console.
     */
    public void calcularContaEmitirFatura() {
        double total = this.calcularConta();
        System.out.println("Fatura da Mesa " + this.numeroDaMesa + ": R$ " + total);
    }
}