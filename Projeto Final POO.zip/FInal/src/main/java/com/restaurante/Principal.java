package com.restaurante;

import javax.swing.JOptionPane;
import java.awt.*;
import java.util.ArrayList;

public class Principal {
    private static final String CLIENTES_FILE = "clientes.txt";
    private static ArrayList<Cliente> clientes = new ArrayList<>();
    private static Menu menu = new Menu();
    private static ArrayList<Mesa> mesasVaranda = new ArrayList<>();
    private static ArrayList<Mesa> mesasSalao = new ArrayList<>();

    public static void main(String[] args) {
        inicializarMesas();
        inicializarMenu();
        carregarClientes();

        while (true) {
            String[] options = {"Adicionar Cliente", "Excluir Cliente", "Alterar Cliente", "Listar Clientes", "Realizar Pedido", "Pagamento", "Salvar e Sair"};
            int choice = JOptionPane.showOptionDialog(null, "Escolha uma opção", "Sistema de Restaurante",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);

            try {
                switch (choice) {
                    case 0:
                        adicionarCliente();
                        break;
                    case 1:
                        excluirCliente();
                        break;
                    case 2:
                        alterarCliente();
                        break;
                    case 3:
                        listarClientes();
                        break;
                    case 4:
                        realizarPedido();
                        break;
                    case 5:
                        pagamento();
                        break;
                    case 6:
                        salvarClientes();
                        JOptionPane.showMessageDialog(null, "Clientes salvos. Saindo...");
                        System.exit(0);
                        break;
                    default:
                        JOptionPane.showMessageDialog(null, "Opção inválida.");
                        break;
                }
            } catch (MesaNaoDisponivelException e) {
                JOptionPane.showMessageDialog(null, "Erro: " + e.getMessage());
            }
        }
    }

    private static void inicializarMesas() {
        for (int i = 0; i < 5; i++) {
            mesasVaranda.add(new MesaVaranda());
            mesasSalao.add(new MesaSalão());
        }
    }

    private static void inicializarMenu() {
        menu.adicionaItem(new ItemDoMenu("Água com gás", "Garrafa de água gaseificada", 4.5, 5));
        menu.adicionaItem(new ItemDoMenu("Coca-cola", "Refrigerante coca-cola", 5.0, 2));
        menu.adicionaItem(new ItemDoMenu("Suco de Laranja", "Copo de suco natural de laranja", 6.0, 10));
        menu.adicionaItem(new ItemDoMenu("Café", "Xícara de café expresso", 3.0, 20));
        menu.adicionaItem(new ItemDoMenu("Hamburguer", "Hamburguer com queijo e bacon", 15.0, 8));
        menu.adicionaItem(new ItemDoMenu("Pizza Margherita", "Pizza com molho de tomate, mussarela e manjericão", 25.0, 5));
        menu.adicionaItem(new ItemDoMenu("Salada Caesar", "Salada com alface, frango, queijo parmesão e croutons", 12.0, 7));
    }
    private static Mesa escolherMesa() {
        ArrayList<String> opcoes = new ArrayList<>();
        ArrayList<Mesa> todasAsMesas = new ArrayList<>();
        todasAsMesas.addAll(mesasVaranda);
        todasAsMesas.addAll(mesasSalao);

        for (Mesa mesa : todasAsMesas) {
            if (mesa.isDisponivel()) {
                opcoes.add("Mesa " + mesa.getNumeroDaMesa() + " - " + (mesa instanceof MesaVaranda ? "Varanda" : "Salão"));
            }
        }

        if (opcoes.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Não há mesas disponíveis.");
            return null;
        }

        String mesaEscolhida = (String) JOptionPane.showInputDialog(null, "Escolha uma mesa:", "Mesas Disponíveis",
                JOptionPane.QUESTION_MESSAGE, null, opcoes.toArray(), opcoes.get(0));

        if (mesaEscolhida != null) {
            int numeroMesa = Integer.parseInt(mesaEscolhida.split(" ")[1]);
            for (Mesa mesa : todasAsMesas) {
                if (mesa.getNumeroDaMesa() == numeroMesa) {
                    return mesa;
                }
            }
        }
        return null;
    }


    private static void carregarClientes() {
        clientes = Cliente.loadClientes(CLIENTES_FILE);
        verificarStatusDasMesas();
        JOptionPane.showMessageDialog(null, "Clientes carregados: " + clientes.size());
    }

    private static void adicionarCliente() throws MesaNaoDisponivelException {
        String nome = JOptionPane.showInputDialog("Nome do cliente:");
        String telefone = JOptionPane.showInputDialog("Telefone do cliente:");

        if (Cliente.isClienteExistente(nome, telefone, clientes)) {
            JOptionPane.showMessageDialog(null, "Cliente já existente: " + nome + ", " + telefone);
            return;
        }

        Mesa mesa = escolherMesa();
        if (mesa != null && !mesa.isDisponivel()) {
            throw new MesaNaoDisponivelException("A mesa " + mesa.getNumeroDaMesa() + " não está disponível.");
        }

        Cliente cliente = new Cliente(nome, telefone, mesa);
        mesa.setDisponivel(false); // Marcar a mesa como indisponível
        clientes.add(cliente);
    }

    private static void excluirCliente() {
        String nome = JOptionPane.showInputDialog("Nome do cliente a ser excluído:");
        Cliente cliente = encontrarClientePorNome(nome);
        if (cliente != null) {
            cliente.getMesa().setDisponivel(true); // Marcar a mesa como disponível novamente
            clientes.remove(cliente);
            salvarClientes();
            JOptionPane.showMessageDialog(null, "Cliente excluído: " + cliente);
        } else {
            JOptionPane.showMessageDialog(null, "Cliente não encontrado.");
        }
    }

    private static void alterarCliente() {
        String nome = JOptionPane.showInputDialog("Nome do cliente a ser alterado:");
        Cliente cliente = encontrarClientePorNome(nome);
        if (cliente != null) {
            String novoNome = JOptionPane.showInputDialog("Novo nome do cliente:", cliente.getNome());
            String novoTelefone = JOptionPane.showInputDialog("Novo telefone do cliente:", cliente.getTelefone());
            cliente.setNome(novoNome);
            cliente.setTelefone(novoTelefone);
            salvarClientes();
            JOptionPane.showMessageDialog(null, "Cliente alterado: " + cliente);
        } else {
            JOptionPane.showMessageDialog(null, "Cliente não encontrado.");
        }
    }

    private static void listarClientes() {
        StringBuilder sb = new StringBuilder("Clientes:\n");
        for (Cliente cliente : clientes) {
            sb.append(cliente.toString()).append("\n");
        }
        JOptionPane.showMessageDialog(null, sb.toString());
    }

    private static void realizarPedido() {
        String nomeCliente = JOptionPane.showInputDialog("Nome do cliente:");
        Cliente cliente = encontrarClientePorNome(nomeCliente);
        if (cliente == null) {
            JOptionPane.showMessageDialog(null, "Cliente não encontrado.");
            return;
        }

        ArrayList<ItemDoMenu> itensPedido = new ArrayList<>();
        while (true) {
            String[] itemNames = menu.getItemNames();
            String itemEscolhido = (String) JOptionPane.showInputDialog(null, "Escolha um item do menu", "Menu",
                    JOptionPane.QUESTION_MESSAGE, null, itemNames, itemNames[0]);
            ItemDoMenu item = menu.getItemByName(itemEscolhido);
            if (item != null) {
                itensPedido.add(item);
                item.reduzirEstoque();
                JOptionPane.showMessageDialog(null, "Item adicionado ao pedido: " + item.getNome());
            }
            int continuar = JOptionPane.showConfirmDialog(null, "Adicionar mais itens?", "Pedido",
                    JOptionPane.YES_NO_OPTION);
            if (continuar != JOptionPane.YES_OPTION) {
                break;
            }
        }
        Pedido pedido = new Pedido(cliente.getMesa(), itensPedido.toArray(new ItemDoMenu[0]));
        cliente.getMesa().adicionarPedido(pedido);
        JOptionPane.showMessageDialog(null, "Pedido realizado: " + pedido);
    }

    private static void pagamento() {
        String nomeCliente = JOptionPane.showInputDialog("Nome do cliente para pagamento:");
        Cliente cliente = encontrarClientePorNome(nomeCliente);
        if (cliente == null) {
            JOptionPane.showMessageDialog(null, "Cliente não encontrado.");
            return;
        }

        double total = cliente.getMesa().calcularConta();
        String[] options = {"Crédito", "Débito", "Dinheiro"};
        int choice = JOptionPane.showOptionDialog(null, "Escolha o método de pagamento", "Pagamento",
                JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);

        switch (choice) {
            case 0:
                JOptionPane.showMessageDialog(null, "Pagamento de R$ " + total + " realizado com Cartão de Crédito.");
                break;
            case 1:
                JOptionPane.showMessageDialog(null, "Pagamento de R$ " + total + " realizado com Cartão de Débito.");
                break;
            case 2:
                JOptionPane.showMessageDialog(null, "Pagamento de R$ " + total + " realizado em Dinheiro.");
                break;
            default:
                JOptionPane.showMessageDialog(null, "Método de pagamento não selecionado.");
                return;
        }

        cliente.saidaCliente();
        clientes.remove(cliente);
        salvarClientes();
    }

    private static Cliente encontrarClientePorNome(String nome) {
        for (Cliente cliente : clientes) {
            if (cliente.getNome().equalsIgnoreCase(nome)) {
                return cliente;
            }
        }
        return null;
    }

    private static void salvarClientes() {
        Cliente.saveClientes(clientes, CLIENTES_FILE);
    }

    // Novo método para verificar o status das mesas
    private static void verificarStatusDasMesas() {
        // Marcar todas as mesas como disponíveis inicialmente
        for (Mesa mesa : mesasVaranda) {
            mesa.setDisponivel(true);
        }
        for (Mesa mesa : mesasSalao) {
            mesa.setDisponivel(true);
        }

        // Verificar quais mesas estão ocupadas pelos clientes
        for (Cliente cliente : clientes) {
            Mesa mesa = cliente.getMesa();
            if (mesa != null) {
                mesa.setDisponivel(false);
            }
        }
    }
}
