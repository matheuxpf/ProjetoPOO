package com.restaurante;

import javax.swing.JOptionPane;
import java.io.Serializable;
import java.util.ArrayList;

/**
 * A classe Cliente representa um cliente em um restaurante,
 * armazenando informações como nome, telefone, código de atendimento,
 * status e a mesa associada.
 */

public class Cliente extends Pessoa implements Serializable {
    /**
     * Código estático usado para gerar códigos de atendimento únicos.
     */
    private static int codigo = 1;

    /**
     * Código de atendimento do cliente.
     */
    private int codigoDeAtendimento;

    /**
     * Status do cliente ('P' para presente, 'A' para ausente).
     */
    private char status;

    /**
     * Mesa associada ao cliente.
     */
    private Mesa mesa;

    /**
     * Construtor da classe Cliente. Inicializa um cliente com nome, telefone e mesa,
     * e atualiza o status da mesa para indisponível.
     *
     * @param nome     O nome do cliente.
     * @param telefone O telefone do cliente.
     * @param mesa     A mesa associada ao cliente.
     */
    public Cliente(String nome, String telefone, Mesa mesa) {
        this.codigoDeAtendimento = codigo++;
        this.nome = nome;
        this.telefone = telefone;
        this.mesa = mesa;
        this.entradaCliente();
        if (mesa != null) {
            mesa.setDisponivel(false);
            JOptionPane.showMessageDialog(null, "Cliente " + this.nome + " foi atribuído à mesa " + this.mesa.getNumeroDaMesa() + ".\nAtendimento cód. " + this.codigoDeAtendimento);
        } else {
            JOptionPane.showMessageDialog(null, "Cliente " + this.nome + " está sem mesa.\nAtendimento cód. " + this.codigoDeAtendimento);
        }
    }

    /**
     * Obtém o código de atendimento do cliente.
     *
     * @return O código de atendimento do cliente.
     */
    public int getCodigoDeAtendimento() {
        return this.codigoDeAtendimento;
    }

    /**
     * Obtém o status do cliente.
     *
     * @return O status do cliente.
     */
    public char getStatus() {
        return this.status;
    }

    /**
     * Obtém a mesa associada ao cliente.
     *
     * @return A mesa associada ao cliente.
     */
    public Mesa getMesa() {
        return this.mesa;
    }

    /**
     * Define a mesa associada ao cliente.
     *
     * @param mesa A nova mesa associada ao cliente.
     */
    public void setMesa(Mesa mesa) {
        this.mesa = mesa;
    }

    /**
     * Define o código de atendimento do cliente.
     *
     * @param codigoDeAtendimento O novo código de atendimento do cliente.
     */
    public void setCodigoDeAtendimento(int codigoDeAtendimento) {
        this.codigoDeAtendimento = codigoDeAtendimento;
    }

    /**
     * Define o status do cliente.
     *
     * @param status O novo status do cliente.
     */
    public void setStatus(char status) {
        this.status = status;
    }

    /**
     * Define o status do cliente como 'P' (presente).
     */
    public void entradaCliente() {
        this.status = 'P';
    }

    /**
     * Define o status do cliente como 'A' (ausente) e torna a mesa disponível.
     */
    public void saidaCliente() {
        this.status = 'A';
        this.mesa.setDisponivel(true);
    }

    /**
     * Retorna uma string representando o status do cliente.
     *
     * @return Uma string que representa o status do cliente.
     */
    public String printStatus() {
        if (this.status == 'P') {
            return "Em atendimento (Cód: " + this.codigoDeAtendimento + ")";
        } else {
            return "Ausente";
        }
    }

    /**
     * Retorna uma string que contém os pedidos do cliente.
     *
     * @return Uma string que representa os pedidos do cliente.
     */
    public String getPedidosAsString() {
        StringBuilder sb = new StringBuilder();
        for (Pedido pedido : mesa.getPedidos()) {
            sb.append(pedido.toString()).append("; ");
        }
        return sb.toString();
    }

    /**
     * Retorna uma string que representa o cliente.
     *
     * @return Uma string que representa o cliente.
     */
    @Override
    public String toString() {
        return "Nome: " + nome + ", Telefone: " + telefone + ", Mesa: " + mesa.getNumeroDaMesa() + ", Código de Atendimento: " + codigoDeAtendimento + ", Status: " + status;
    }

    /**
     * Salva uma lista de clientes em um arquivo.
     *
     * @param clientes A lista de clientes a ser salva.
     * @param fileName O nome do arquivo onde os clientes serão salvos.
     */
    public static void saveClientes(ArrayList<Cliente> clientes, String fileName) {
        FileUtil.saveClientesToFile(clientes, fileName);
    }

    /**
     * Carrega uma lista de clientes de um arquivo.
     *
     * @param fileName O nome do arquivo de onde os clientes serão carregados.
     * @return A lista de clientes carregada do arquivo.
     */
    public static ArrayList<Cliente> loadClientes(String fileName) {
        return FileUtil.readClientesFromFile(fileName);
    }

    /**
     * Verifica se um cliente com um determinado nome e telefone já existe na lista de clientes.
     *
     * @param nome     O nome do cliente a ser verificado.
     * @param telefone O telefone do cliente a ser verificado.
     * @param clientes A lista de clientes.
     * @return true se o cliente já existe, false caso contrário.
     */
    public static boolean isClienteExistente(String nome, String telefone, ArrayList<Cliente> clientes) {
        for (Cliente cliente : clientes) {
            if (cliente.getNome().equalsIgnoreCase(nome) && cliente.getTelefone().equals(telefone)) {
                return true;
            }
        }
        return false;
    }
}
