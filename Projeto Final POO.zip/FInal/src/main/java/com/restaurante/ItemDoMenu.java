package com.restaurante;

import java.io.Serializable;

/**
 * A classe ItemDoMenu representa um item de um menu, com nome, descrição, preço e quantidade em estoque.
 */
public class ItemDoMenu implements Serializable {

    /**
     * Nome do item do menu.
     */
    private String nome;

    /**
     * Descrição do item do menu.
     */
    private String descricao;

    /**
     * Preço do item do menu.
     */
    private double preco;

    /**
     * Quantidade em estoque do item do menu.
     */
    private int quantidadeEstoque;

    /**
     * Construtor da classe ItemDoMenu.
     *
     * @param nome              Nome do item do menu.
     * @param descricao         Descrição do item do menu.
     * @param preco             Preço do item do menu.
     * @param quantidadeEstoque Quantidade em estoque do item do menu.
     */
    public ItemDoMenu(String nome, String descricao, double preco, int quantidadeEstoque) {
        this.nome = nome;
        this.descricao = descricao;
        this.preco = preco;
        this.quantidadeEstoque = quantidadeEstoque;
    }

    /**
     * Obtém o nome do item do menu.
     *
     * @return Nome do item do menu.
     */
    public String getNome() {
        return nome;
    }

    /**
     * Obtém o preço do item do menu.
     *
     * @return Preço do item do menu.
     */
    public double getPreco() {
        return preco;
    }

    /**
     * Obtém a quantidade em estoque do item do menu.
     *
     * @return Quantidade em estoque do item do menu.
     */
    public int getQuantidadeEstoque() {
        return quantidadeEstoque;
    }

    /**
     * Reduz a quantidade em estoque do item do menu em uma unidade.
     */
    public void reduzirEstoque() {
        this.quantidadeEstoque--;
    }

    /**
     * Verifica a quantidade em estoque do item do menu e imprime uma mensagem
     * se o estoque estiver esgotado.
     */
    public void verificaEstoque() {
        if (quantidadeEstoque <= 0) {
            System.out.println("Estoque de " + nome + " esgotado.");
        }
    }

    /**
     * Retorna uma representação em String do item do menu.
     *
     * @return Uma String que representa o item do menu.
     */
    @Override
    public String toString() {
        return nome + " - " + descricao + " - " + preco + " - " + quantidadeEstoque;
    }
}