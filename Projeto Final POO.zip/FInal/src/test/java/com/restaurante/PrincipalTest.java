package com.restaurante;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;

public class PrincipalTest {

    private ArrayList<Cliente> clientes;
    private Menu menu;
    private ArrayList<Mesa> mesasVaranda;
    private ArrayList<Mesa> mesasSalao;

    @BeforeEach
    public void setUp() {
        // Configura o ambiente de teste
        clientes = new ArrayList<>();
        menu = new Menu();
        mesasVaranda = new ArrayList<>();
        mesasSalao = new ArrayList<>();

        // Inicializa mesas
        for (int i = 0; i < 5; i++) {
            mesasVaranda.add(new MesaVaranda());
            mesasSalao.add(new MesaSalão());
        }

        // Inicializa o menu
        menu.adicionaItem(new ItemDoMenu("Água com gás", "Garrafa de água gaseificada", 4.5, 5));
        menu.adicionaItem(new ItemDoMenu("Coca-cola", "Refrigerante coca-cola", 5.0, 2));

        // Adiciona um cliente para testes
        Cliente cliente = new Cliente("João", "123456789", mesasVaranda.get(0));
        clientes.add(cliente);
    }

    @Test
    public void testAdicionarCliente() {
        // Adiciona um cliente
        Cliente cliente = new Cliente("Maria", "987654321", mesasVaranda.get(1));
        clientes.add(cliente);

        assertTrue(clientes.stream().anyMatch(c -> c.getNome().equals("Maria") && c.getTelefone().equals("987654321")));
    }

    @Test
    public void testExcluirCliente() {
        Cliente cliente = new Cliente("Pedro", "111222333", mesasSalao.get(0));
        clientes.add(cliente);
        clientes.remove(cliente);

        assertFalse(clientes.stream().anyMatch(c -> c.getNome().equals("Pedro")));
    }

    @Test
    public void testRealizarPedido() {
        Cliente cliente = new Cliente("Ana", "444555666", mesasVaranda.get(2));
        ArrayList<ItemDoMenu> itensPedido = new ArrayList<>();
        itensPedido.add(menu.getItemByName("Água com gás"));

        Pedido pedido = new Pedido(cliente.getMesa(), itensPedido.toArray(new ItemDoMenu[0]));
        cliente.getMesa().adicionarPedido(pedido);

        assertTrue(cliente.getMesa().getPedidos().contains(pedido));
    }

    @Test
    public void testVerificarStatusMesa() {
        Cliente cliente = new Cliente("Carlos", "777888999", mesasSalao.get(1));
        assertFalse(mesasSalao.get(1).isDisponivel());

        cliente.saidaCliente();
        assertTrue(mesasSalao.get(1).isDisponivel());
    }

    @Test
    public void testEstoqueItemMenu() {
        ItemDoMenu item = menu.getItemByName("Coca-cola");
        int quantidadeEstoqueAntes = item.getQuantidadeEstoque();

        item.reduzirEstoque();

        assertEquals(quantidadeEstoqueAntes - 1, item.getQuantidadeEstoque());
    }
}
